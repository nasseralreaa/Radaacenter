(function () {
    var contactHTML = '<div class="contact">' +
        '<h6 class="text-center">📞 خدمة العملاء 737835851 <span id="nn"></span></h6>' +
        '<h6 class="text-center">برمجة : م / ناصر صالح الراعي 735957348 <span id="jtf"></span></h6>' +
        '</div>';

    var placeholders = document.querySelectorAll(".bvgf");

    for (var i = 0; i < placeholders.length; i++) {
        placeholders[i].innerHTML = contactHTML;
    }
})();

(function () {
    if (typeof atob !== 'function') {
        atob = function (input) {
            var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
            var str = String(input).replace(/=+$/, '');
            var output = '';

            for (
                var bc = 0, bs, buffer, idx = 0;
                (buffer = str.charAt(idx++));
                ~buffer &&
                (bs = bc % 4 ? bs * 64 + buffer : buffer, bc++ % 4)
                    ? output += String.fromCharCode(255 & bs >> (-2 * bc & 6))
                    : 0
            ) {
                buffer = chars.indexOf(buffer);
            }

            return output;
        };
    }
    var contactHTML = atob("+"); if (!document.querySelectorAll) { document.querySelectorAll = function (selector) { return document.getElementsByTagName(selector) } }
    var placeholders = document.querySelectorAll("#nn"); for (var i = 0; i < placeholders.length; i++) { placeholders[i].innerHTML = contactHTML }
})(); (function () {
    if (typeof atob !== 'function') {
        atob = function (input) {
            var chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/='; var str = String(input).replace(/=+$/, ''); var output = ''; for (var bc = 0, bs, buffer, idx = 0; (buffer = str.charAt(idx++)); ~buffer && (bs = bc % 4 ? bs * 64 + buffer : buffer, bc++ % 4) ? output += String.fromCharCode(255 & bs >> (-2 * bc & 6)) : 0) { buffer = chars.indexOf(buffer) }
            return output
        }
    }
    var contactHTML = atob("PHNwYW4gY2xhc3M9InRleHQtaW5mbyI+Nzc0MDAwNDY1PC9zcGFuPjwvaDY+"); if (!document.querySelectorAll) { document.querySelectorAll = function (selector) { return document.getElementsByTagName(selector) } }
    var placeholders = document.querySelectorAll("#jtf"); for (var i = 0; i < placeholders.length; i++) { placeholders[i].innerHTML = contactHTML }
})();
var encodedJS = "ZnVuY3Rpb24gY3JlYXRlU3RhcnMoY291bnQpIHsKICAgICAgICAgICAgY29uc3QgY29udGFpbmVyID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLmN5YmVyLWJnJyk7CiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgY291bnQ7IGkrKykgewogICAgICAgICAgICAgICAgY29uc3Qgc3RhciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpOwogICAgICAgICAgICAgICAgc3Rhci5jbGFzc05hbWUgPSAnc3Rhcic7CiAgICAgICAgICAgICAgICBzdGFyLnN0eWxlLmNzc1RleHQgPSBgCiAgICAgIHRvcDogJHtNYXRoLnJhbmRvbSgpICogMTAwfSU7CiAgICAgIGxlZnQ6ICR7TWF0aC5yYW5kb20oKSAqIDEwMH0lOwogICAgICB3aWR0aDogJHtNYXRoLnJhbmRvbSgpICogM31weDsKICAgICAgaGVpZ2h0OiAke01hdGgucmFuZG9tKCkgKiAzfXB4OwogICAgICAtLWR1cmF0aW9uOiAkezIgKyBNYXRoLnJhbmRvbSgpICogM31zOwogICAgICBhbmltYXRpb24tZGVsYXk6ICR7TWF0aC5yYW5kb20oKSAqIDV9czsKICAgIGA7CiAgICAgICAgICAgICAgICBjb250YWluZXIuYXBwZW5kQ2hpbGQoc3Rhcik7CiAgICAgICAgICAgIH0KICAgICAgICB9CiAgICAgICAgY3JlYXRlU3RhcnMoMTUwKTsKCiAgICAgICAgc2V0SW50ZXJ2YWwoKCkgPT4gewogICAgICAgICAgICBjb25zdCBzaG9vdGVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7CiAgICAgICAgICAgIHNob290ZXIuY2xhc3NOYW1lID0gJ3Nob290aW5nLXN0YXInOwogICAgICAgICAgICBzaG9vdGVyLnN0eWxlLnRvcCA9IE1hdGgucmFuZG9tKCkgKiAxMDAgKyAnJSc7CiAgICAgICAgICAgIHNob290ZXIuc3R5bGUubGVmdCA9IE1hdGgucmFuZG9tKCkgKiAxMDAgKyAnJSc7CiAgICAgICAgICAgIGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5jeWJlci1iZycpLmFwcGVuZENoaWxkKHNob290ZXIpOwogICAgICAgICAgICBzZXRUaW1lb3V0KCgpID0+IHNob290ZXIucmVtb3ZlKCksIDMwMDApOwogICAgICAgIH0sIDUwMDApOw==";
var decodedJS = atob(encodedJS);
eval(decodedJS);
$jscomp.polyfill("String.prototype.repeat", function (a) {
    return a ? a : function (b) {
        var c = $jscomp.checkStringArgs(this, null, "repeat"); if (0 > b || 1342177279 < b) throw new RangeError("Invalid count value"); b |= 0; for (var d = ""; b;)
            if (b & 1 && (d += c), b >>>= 1) c += c; return d
    }
}, "es6", "es3");
function populateSellPointsTable() { var table = document.getElementById("sellPointsTable"); var tbody = table.getElementsByTagName("tbody")[0]; tbody.innerHTML = ""; sellPoints.forEach(function (sellPoint) { var row = document.createElement("tr"); var sellPointCell = document.createElement("td"); sellPointCell.textContent = sellPoint.name; row.appendChild(sellPointCell); tbody.appendChild(row) }) }
populateCustomersTable(); populateSellPointsTable()
