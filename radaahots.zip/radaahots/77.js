document.addEventListener("DOMContentLoaded", function () { populateDropdownAndFillInput() }); function saveUsernameAndPassword() {
    var username = document.getElementById('usernameInput').value.trim();
    var password = document.getElementById('passwordInput').value.trim();
    var speed = document.getElementById('speed').value.trim();
    if (username === '') { alert('يرجى إدخال اسم المستخدم'); return }
        var expires = new Date();
        expires.setTime(expires.getTime() + 30 * 24 * 60 * 60 * 1000);
        var expiresStr = ";expires=" + expires.toUTCString() + "; path=/";
        document.cookie = "username=" + encodeURIComponent(username) + expiresStr;
    document.cookie = "password=" + encodeURIComponent(password) + expiresStr;
    document.cookie = "speed=" + encodeURIComponent(speed) + expiresStr;
 saveUsername(username, password); populateDropdownAndFillInput(); displayUsernames()
}
function saveUsername(username, password) {
    var storedData = localStorage.getItem('usernamesAndPasswords'); var usernamesAndPasswords = storedData ? JSON.parse(storedData) : { usernames: [], passwords: [] }; var index = usernamesAndPasswords.usernames.indexOf(username); if (index !== -1) { usernamesAndPasswords.passwords[index] = password } else {
        if (usernamesAndPasswords.usernames.length >= 5) { usernamesAndPasswords.usernames.shift(); usernamesAndPasswords.passwords.shift() }
        usernamesAndPasswords.usernames.push(username); usernamesAndPasswords.passwords.push(password)
    }
    localStorage.setItem('usernamesAndPasswords', JSON.stringify(usernamesAndPasswords))
}
function fillInputField() {
    var dropdown = document.getElementById('usernameDropdown'); var selectedOption = dropdown.options[dropdown.selectedIndex].value; if (selectedOption === 'refresh') { location.reload(); return }
    var parts = selectedOption.split('@'); var selectedUsername = parts[0] || ''; var selectedPassword = parts[1] || ''; document.getElementById('usernameInput').value = selectedUsername; document.getElementById('passwordInput').value = selectedPassword
}
function populateDropdownAndFillInput() {
    var storedData = localStorage.getItem('usernamesAndPasswords'); var usernamesAndPasswords = storedData ? JSON.parse(storedData) : { usernames: [], passwords: [] }; var cards = []; for (var i = 0; i < usernamesAndPasswords.usernames.length; i++) { var username = usernamesAndPasswords.usernames[i]; var password = usernamesAndPasswords.passwords[i] || ''; cards.unshift(username + '@' + password) }
    var dropdown = document.getElementById('usernameDropdown'); dropdown.innerHTML = ''; var defaultOption = document.createElement('option'); defaultOption.value = ''; defaultOption.textContent = "الكروت السابقة ▼"; dropdown.appendChild(defaultOption); cards.forEach(function (card) { var option = document.createElement('option'); option.value = card; option.textContent = card; dropdown.appendChild(option) }); var refreshOption = document.createElement('option'); refreshOption.value = 'refresh'; refreshOption.textContent = "تحديث "; dropdown.appendChild(refreshOption)
}
function displayUsernames() { var storedData = localStorage.getItem('usernamesAndPasswords'); var usernamesAndPasswords = storedData ? JSON.parse(storedData) : { usernames: [], passwords: [] }; var usernamesList = document.getElementById('usernamesList'); usernamesList.innerHTML = ''; usernamesAndPasswords.usernames.forEach(function (username, index) { var password = usernamesAndPasswords.passwords[index] ? '@' + usernamesAndPasswords.passwords[index] : ''; var listItem = document.createElement('li'); listItem.textContent = username + password; usernamesList.appendChild(listItem) }) }
function disableDropdown() { var inputField = document.getElementById('usernameInput'); var dropdown = document.getElementById('usernameDropdown'); dropdown.disabled = inputField.value ? !0 : !1 }